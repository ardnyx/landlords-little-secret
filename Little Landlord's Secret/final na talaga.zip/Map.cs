﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Little_Landlord_s_Secret
{
    class Map
    {
        //For Ending 2
        public static bool room1key = false;
        public static bool drawerkey = false;
        public static bool discoveredBody = false;
        public static bool someonedoor = false;

        //For kitchen scenarios
        public static bool talkLandlady = false;
        public static bool rustyknife = false;
        public static bool enterKitchen = false;
        public static bool lieknife = false;
        public static bool pickedupknife = false;

        public static bool joneroom = false;

        public static bool headlock = false;

        public static bool escapethehouse = false;

        public static bool fetchcorns = false;
    }
}
